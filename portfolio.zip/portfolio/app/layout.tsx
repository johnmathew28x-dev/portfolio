import type { Metadata, Viewport } from "next";
import "./globals.css";
import { site } from "@/data/site";

const description = `${site.name} is an Information Technology student and web developer at Northeastern College. Explore selected projects, skills, and education.`;

export const metadata: Metadata = {
  title: `${site.name} | Portfolio`,
  description,
  openGraph: {
    title: `${site.name} | Portfolio`,
    description,
    type: "website",
  },
  icons: { icon: "/icon.svg" },
};

export const viewport: Viewport = { themeColor: "#000000", colorScheme: "dark" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

# John Matthew Ong — Portfolio

Next.js 14, React, TypeScript, and Tailwind CSS. A dark, responsive portfolio inspired by the supplied futuristic developer-portfolio reference, with a floating navigation bar, subtle grid lighting, bento-style About cards, and project preview artwork.

## Run locally
```bash
npm install
npm run dev     # http://localhost:3000
npm run build   # production build check
```

## Edit your content
- `data/site.ts` — name, title, introduction, education, contact links, strengths, and skills
- `data/projects.ts` — project descriptions, technologies, screenshots, and optional GitHub/demo links
- `public/profile.jpg` — profile photo
- `app/icon.svg` — favicon

Empty contact and project URLs are hidden, so the site does not show inactive links. Project cards use clearly labeled concept artwork until a real screenshot is supplied.

## Deploy to Vercel
1. Push this folder to a GitHub repository.
2. Go to https://vercel.com/new, import the repo. Next.js is detected automatically.
3. Click Deploy. Every push to `main` redeploys.

Or from the terminal: `npx vercel` (preview) and `npx vercel --prod`.

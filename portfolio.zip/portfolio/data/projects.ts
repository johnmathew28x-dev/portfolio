// Project details are centralized here. Add a screenshot and repository/demo URL when available.
export type Project = {
  title: string;
  description: string;
  tech: string[];
  image?: string;
  preview: "web" | "mobile" | "community" | "alumni-admin" | "portfolio";
  github?: string;
  demo?: string;
};

export const projects: Project[] = [
  {
    title: "Alumni Tracking System",
    description:
      "An Education Department admin portal for managing alumni profiles, education and employment records, training, announcements, events, opportunities, and graduate tracer surveys.",
    tech: ["PHP", "MySQL"],
    preview: "alumni-admin",
    github: "https://github.com/johnmathew28x-dev/alumni_tracking_system",
  },
  {
    title: "Alumni Portal Mobile App",
    description:
      "A Flutter companion app with a mobile-first home for alumni profiles, event attendance, tracer surveys, career updates, and college announcements.",
    tech: ["Flutter", "Dart", "PHP API"],
    preview: "mobile",
  },
  {
    title: "Personal Portfolio Website",
    description:
      "Designed and built a responsive portfolio to introduce my background, present selected web and mobile projects, and organize my skills and professional interests.",
    tech: ["Next.js", "React", "TypeScript", "CSS"],
    preview: "portfolio",
  },
];

export type Certification = {
  name: string;
  issuer: string;
  issued: string;
  preview: string;
  credentialUrl?: string;
  credentialLabel?: string;
};

export const certifications: Certification[] = [
  {
    name: "Foundational C# with Microsoft",
    issuer: "freeCodeCamp and Microsoft",
    issued: "September 27, 2026",
    preview: "/certificates/foundational-csharp-with-microsoft.png",
    credentialUrl: "https://www.freecodecamp.org/certification/fcc-4ef0b92f-9bf7-4007-bd58-3dd40c86aa62/foundational-c-sharp-with-microsoft",
    credentialLabel: "Verify credential",
  },
  {
    name: "Introduction to Computer Systems Servicing",
    issuer: "TESDA Online Program",
    issued: "September 27, 2026",
    preview: "/certificates/previews/introduction-to-computer-systems-servicing.png",
    credentialUrl: "/certificates/introduction-to-computer-systems-servicing.pdf",
  },
  {
    name: "Setting Up Computer Networks",
    issuer: "TESDA Online Program",
    issued: "September 27, 2026",
    preview: "/certificates/previews/setting-up-computer-networks.png",
    credentialUrl: "/certificates/setting-up-computer-networks.pdf",
  },
  {
    name: "Installing and Configuring Computer Systems",
    issuer: "TESDA Online Program",
    issued: "September 27, 2026",
    preview: "/certificates/previews/installing-and-configuring-computer-systems.png",
    credentialUrl: "/certificates/installing-and-configuring-computer-systems.pdf",
  },
  {
    name: "Maintaining Computer Systems and Networks",
    issuer: "TESDA Online Program",
    issued: "September 27, 2026",
    preview: "/certificates/previews/maintaining-computer-systems-and-networks.png",
    credentialUrl: "/certificates/maintaining-computer-systems-and-networks.pdf",
  },
  {
    name: "Setting Up Computer Servers",
    issuer: "TESDA Online Program",
    issued: "September 27, 2026",
    preview: "/certificates/previews/setting-up-computer-servers.png",
    credentialUrl: "/certificates/setting-up-computer-servers.pdf",
  },
  {
    name: "AI for MSME Advancement: AI Training for Business Owners",
    issuer: "DICT Region V – Catanduanes Provincial Office",
    issued: "October 10, 2026",
    preview: "/certificates/previews/ai-for-msme-advancement-dict.png",
    credentialUrl: "/certificates/ai-for-msme-advancement-dict.pdf",
  },
  {
    name: "IT Customer Support Basics",
    issuer: "Cisco Networking Academy",
    issued: "September 24, 2026",
    preview: "/certificates/previews/it-customer-support-basics.png",
    credentialUrl: "/certificates/it-customer-support-basics.pdf",
  },
  {
    name: "Networking Basics",
    issuer: "Cisco Networking Academy",
    issued: "September 25, 2026",
    preview: "/certificates/previews/networking-basics.png",
    credentialUrl: "/certificates/networking-basics.pdf",
  },
  {
    name: "Integrating IoT in Capstone Project",
    issuer: "Northeastern College – 10th I.T. Week 2026",
    issued: "August 27, 2026",
    preview: "/certificates/integrating-iot-in-capstone-project.jpg",
  },
  {
    name: "Agentic AI",
    issuer: "Northeastern College – 10th I.T. Week 2026",
    issued: "August 27, 2026",
    preview: "/certificates/agentic-ai.jpg",
  },
  {
    name: "Video Editing Tips & Tricks",
    issuer: "Northeastern College – 10th I.T. Week 2026",
    issued: "August 27, 2026",
    preview: "/certificates/video-editing-tips-and-tricks.jpg",
  },
  {
    name: "Programming Fundamentals",
    issuer: "Northeastern College – 10th I.T. Week 2026",
    issued: "August 27, 2026",
    preview: "/certificates/programming-fundamentals.jpg",
  },
];

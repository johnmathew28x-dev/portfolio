// Keep personal details and contact links in one place so the portfolio stays easy to update.
export const site = {
  name: "John Matthew Ong",
  initials: "JM",
  title: "IT Student & Web Developer",
  tagline:
    "I build thoughtful web experiences with PHP, MySQL, and JavaScript, and bring the visual details to life with design.",
  about:
    "I’m John Matthew Ong, an Information Technology student at Northeastern College. I enjoy building for the web and exploring how clear design can make digital tools easier to use. I’m continuing to grow through hands-on projects, and I bring teamwork, creativity, time management, and responsibility to the work I take on.",
  education: [
    {
      period: "2024 - Present",
      school: "Northeastern College, Santiago City, Isabela",
      program: "Bachelor of Science in Information Technology (BSIT) - Third year, first semester",
    },
  ],
  // Add an address when you are ready to publish it. Direct contact links stay hidden while empty.
  email: "johnmathew28x@gmail.com",
  socials: {
    github: "https://github.com/johnmathew28x-dev",
    linkedin: "",
    instagram: "https://www.instagram.com/yue.gfx/",
    whatsapp: "https://wa.me/qr/F64IBA7VD7ZNJ1",
  },
} as const;

export type SkillGroup = {
  name: string;
  description: string;
  items: string[];
};

export const skillGroups: SkillGroup[] = [
  {
    name: "Frontend",
    description: "Building the visible, interactive parts of a website.",
    items: ["HTML & CSS", "JavaScript", "Bootstrap"],
  },
  {
    name: "Mobile development",
    description: "Building cross-platform apps for mobile and web.",
    items: ["Flutter", "Dart"],
  },
  {
    name: "Backend & data",
    description: "Working with server-side code and relational data.",
    items: ["PHP", "MySQL"],
  },
  {
    name: "Visual design",
    description: "Creating and refining visual assets for digital work.",
    items: ["Photoshop", "Adobe Illustrator"],
  },
];

export const strengths = ["Teamwork", "Time management", "Creativity", "Responsibility"];

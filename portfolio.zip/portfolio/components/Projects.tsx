import Image from "next/image";
import {
  ArrowUpRight,
  BadgeCheck,
  CalendarDays,
  ChevronRight,
  ClipboardList,
  FileText,
  Github,
  Home,
  Megaphone,
  Moon,
  UserRound,
  Sparkles,
} from "lucide-react";
import { projects, type Project } from "@/data/projects";
import { site } from "@/data/site";

function AlumniMobileArtwork() {
  return (
    <div
      className="project-art project-art-mobile alumni-mobile-art"
      role="img"
      aria-label="Alumni portal mobile app concept showing the home dashboard, attendance, surveys, and bottom navigation"
    >
      <div className="alumni-mobile-copy" aria-hidden="true">
        <span className="alumni-mobile-eyebrow">NORTHEASTERN COLLEGE · EDUCATION</span>
        <h4>Stay connected<br />to your next chapter.</h4>
        <p>A pocket-sized home for alumni records, campus events, career updates, and tracer surveys.</p>
        <div className="alumni-mobile-features">
          <span><CalendarDays size={13} /> Events & updates</span>
          <span><FileText size={13} /> Alumni records</span>
          <span><ClipboardList size={13} /> Tracer surveys</span>
        </div>
      </div>

      <div className="alumni-device" aria-hidden="true">
        <div className="alumni-device-screen">
          <div className="alumni-status-bar"><span>9:41</span><span>● ▮▮▮ ◖</span></div>
          <div className="alumni-app-header">
            <Image src="/projects/college-of-education-logo.webp" alt="" width={38} height={38} />
            <div><strong>Home</strong><span>COLLEGE OF EDUCATION</span></div>
            <Moon size={13} />
            <span className="alumni-logout-mark">↗</span>
          </div>

          <div className="alumni-dashboard-content">
            <section className="alumni-welcome-card">
              <div className="alumni-welcome-brand">
                <Image src="/projects/college-of-education-logo.webp" alt="" width={30} height={30} />
                <span><small>COLLEGE OF EDUCATION</small><b>ALUMNI PORTAL</b></span>
              </div>
              <h5>Welcome back,<br />John Matthew</h5>
              <p>Alumni ID · NEC-2026-00010</p>
              <span className="alumni-verified"><BadgeCheck size={12} /> Profile verified</span>
            </section>

            <div className="alumni-section-title"><strong>At a glance</strong><span>OVERVIEW</span></div>
            <div className="alumni-attendance-card">
              <span className="alumni-app-icon"><CalendarDays size={15} /></span>
              <span className="alumni-attendance-copy"><b>Event attendance</b><small>0 of 3 completed events</small></span>
              <strong>0%</strong>
            </div>

            <div className="alumni-section-title"><strong>Active surveys</strong><span>2 OPEN</span></div>
            <div className="alumni-survey-card">
              <span className="alumni-app-icon"><ClipboardList size={15} /></span>
              <span><b>2026 Graduate Tracer Survey</b><small>In progress</small></span>
              <ChevronRight size={15} />
            </div>
            <div className="alumni-survey-card alumni-survey-card-secondary">
              <span className="alumni-app-icon"><ClipboardList size={15} /></span>
              <span><b>2024 Graduate Tracer Study</b><small>Not started</small></span>
              <ChevronRight size={15} />
            </div>
          </div>

          <nav className="alumni-bottom-nav" aria-label="App navigation">
            <span className="active"><Home size={13} /><small>Home</small></span>
            <span><FileText size={13} /><small>Records</small></span>
            <span><Megaphone size={13} /><small>Updates</small></span>
            <span><ClipboardList size={13} /><small>Surveys</small></span>
            <span><UserRound size={13} /><small>Profile</small></span>
          </nav>
        </div>
      </div>

      <span className="project-art-label">Mobile app concept</span>
    </div>
  );
}

function AlumniTrackingArtwork() {
  return (
    <div
      className="project-art project-art-admin alumni-admin-art alumni-login-art"
      role="img"
      aria-label="College of Education web portal preview with a description of alumni records, events, and tracer surveys beside its sign-in page"
    >
      <div className="alumni-mobile-copy alumni-login-copy" aria-hidden="true">
        <span className="alumni-mobile-eyebrow">NORTHEASTERN COLLEGE · WEB PORTAL</span>
        <h4>One portal.<br />A stronger alumni community.</h4>
        <p>A central place for alumni to access records, campus events, career updates, and graduate tracer surveys.</p>
        <div className="alumni-mobile-features">
          <span><FileText size={13} /> Alumni records</span>
          <span><CalendarDays size={13} /> Events & updates</span>
          <span><ClipboardList size={13} /> Tracer surveys</span>
        </div>
      </div>

      <div className="admin-laptop-wrap alumni-login-laptop-wrap" aria-hidden="true">
        <div className="admin-laptop-frame alumni-login-laptop-frame">
          <div className="admin-laptop-screen alumni-login-screen">
            <Image
              src="/projects/alumni-tracking-login.png"
              alt=""
              fill
              sizes="(max-width: 720px) 100vw, 50vw"
            />
          </div>
        </div>
        <div className="admin-laptop-base"><span /></div>
      </div>
      <span className="project-art-label">Alumni portal sign-in</span>
    </div>
  );
}

function PersonalPortfolioArtwork() {
  return (
    <div
      className="project-art personal-portfolio-art"
      role="img"
      aria-label="Responsive laptop and phone mockups of John Matthew Ong's portfolio website"
    >
      <div className="admin-laptop-wrap personal-laptop-wrap" aria-hidden="true">
        <div className="admin-laptop-frame personal-laptop-frame">
          <div className="personal-portfolio-screen">
            <header className="portfolio-preview-nav">
              <span className="portfolio-preview-mark">JM</span>
              <b>John Matthew <i>Ong</i></b>
              <nav><span>About</span><span>Skills</span><strong>Projects</strong><span>Contact</span></nav>
            </header>
            <main className="portfolio-preview-hero">
              <section className="portfolio-preview-copy">
                <span className="portfolio-preview-eyebrow"><Sparkles size={9} /> A PORTFOLIO BY JOHN MATTHEW ONG</span>
                <small>Hello, I&apos;m</small>
                <h4>{site.name}<em>{site.title}</em></h4>
                <p>{site.tagline}</p>
                <div className="portfolio-preview-actions"><span>Explore projects <ArrowUpRight size={9} /></span><span>Download résumé</span></div>
                <div className="portfolio-preview-social"><i /><i /><i /><span>Design × Development</span></div>
              </section>
              <div className="portfolio-preview-visual">
                <div className="portfolio-preview-orbit portfolio-orbit-one" />
                <div className="portfolio-preview-orbit portfolio-orbit-two" />
                <div className="portfolio-preview-photo"><Image src="/profile.jpg" alt="" width={874} height={874} /></div>
                <span className="portfolio-preview-note">Open to learning</span>
                <span className="portfolio-preview-caption"><b>JM</b><span><strong>{site.name}</strong><small>Information Technology student</small></span></span>
              </div>
            </main>
          </div>
        </div>
        <div className="admin-laptop-base personal-laptop-base"><span /></div>
      </div>

      <div className="personal-phone-wrap" aria-hidden="true">
        <div className="personal-phone-frame">
          <div className="personal-phone-screen">
            <div className="personal-phone-status"><span>9:41</span><span>● ▮▮▮ ◖</span></div>
            <header className="personal-phone-nav">
              <span className="portfolio-preview-mark">JM</span>
              <b>John Matthew <i>Ong</i></b>
              <span className="personal-phone-menu">☰</span>
            </header>
            <div className="personal-phone-content">
              <span className="personal-phone-eyebrow"><Sparkles size={7} /> PORTFOLIO</span>
              <small>Hello, I&apos;m</small>
              <h5>John Matthew<br />Ong</h5>
              <p>IT Student &amp; Web Developer</p>
              <div className="personal-phone-photo"><Image src="/profile.jpg" alt="" width={874} height={874} /></div>
              <span className="personal-phone-button">Explore projects <ArrowUpRight size={8} /></span>
            </div>
            <span className="personal-phone-home" />
          </div>
        </div>
      </div>

      <span className="project-art-label">Responsive web + mobile mockup</span>
    </div>
  );
}

function ProjectArtwork({ project }: { project: Project }) {
  if (project.preview === "mobile") {
    return <AlumniMobileArtwork />;
  }

  if (project.preview === "alumni-admin") {
    return <AlumniTrackingArtwork />;
  }

  if (project.preview === "portfolio") {
    return <PersonalPortfolioArtwork />;
  }

  if (project.image) {
    return (
      <div className="project-image-wrap">
        <Image
          src={project.image}
          alt={`${project.title} project preview`}
          width={1200}
          height={720}
          className="project-image"
          sizes="(max-width: 768px) 100vw, 50vw"
        />
      </div>
    );
  }

  return (
    <div
      className={`project-art project-art-${project.preview}`}
      role="img"
      aria-label={`Illustrative interface concept for ${project.title}`}
    >
      <div className="art-window">
        <div className="art-window-bar">
          <span className="window-controls"><i /><i /><i /></span>
          <span className="art-url">{project.preview === "community" ? "SK / COMMUNITY" : "ALUMNI / PORTAL"}</span>
          <span className="art-window-menu">•••</span>
        </div>

        <div className="dashboard-preview-layout">
          <aside className="art-sidebar">
            <span className="art-logo"><i />{project.preview === "community" ? "SK CONNECT" : "ALUMNI"}</span>
            <span className="art-nav-active" /><span /><span /><span /><span />
            <div className="art-sidebar-bottom" />
          </aside>
          <div className="art-dashboard">
            <div className="art-dashboard-top"><div><i /><i /></div><b>JM</b></div>
            <div className="art-greeting"><span>OVERVIEW</span><strong>{project.preview === "community" ? "Community dashboard" : "Alumni dashboard"}</strong></div>
            <div className="art-stats"><i /><i /><i /></div>
            <div className="art-panels">
              <div className="art-chart"><span /><div className="chart-lines"><i /><i /><i /><i /><i /><i /><i /></div></div>
              <div className="art-feed"><i /><i /><i /></div>
            </div>
            <div className="art-table"><i /><i /><i /></div>
          </div>
        </div>
      </div>
      <span className="project-art-label">Illustrative project preview</span>
    </div>
  );
}

export default function Projects() {
  return (
    <section id="projects" className="section-shell section-divider projects-section">
      <div className="container section-content">
        <div className="section-heading section-heading-row" data-reveal>
          <div>
            <p className="eyebrow">03 / Selected work</p>
            <h2>Projects with<br /><span>purpose behind them.</span></h2>
          </div>
          <p className="section-lede">A selection of web and mobile work focused on useful tools and connected communities.</p>
        </div>

        <div className="projects-grid">
          {projects.map((project, index) => (
            <article className="project-card" key={project.title} data-reveal data-reveal-delay={index * 100}>
              <div className="project-card-visual"><ProjectArtwork project={project} /></div>
              <div className="project-card-content">
                <div className="project-title-row">
                  <div>
                    <p className="card-kicker">Featured project / 0{index + 1}</p>
                    <h3>{project.title}</h3>
                  </div>
                  {(project.github || project.demo) && <ArrowUpRight className="project-arrow" size={19} aria-hidden="true" />}
                </div>
                <p className="project-description">{project.description}</p>
                <ul className="project-tech">
                  {project.tech.map((technology) => <li key={technology}>{technology}</li>)}
                </ul>
                {(project.github || project.demo) && (
                  <div className="project-links">
                    {project.github && <a href={project.github} target="_blank" rel="noopener noreferrer"><Github size={15} /> {project.preview === "alumni-admin" ? "View on GitHub" : "Source"} <ArrowUpRight size={14} /></a>}
                    {project.demo && <a href={project.demo} target="_blank" rel="noopener noreferrer">Live demo <ArrowUpRight size={14} /></a>}
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

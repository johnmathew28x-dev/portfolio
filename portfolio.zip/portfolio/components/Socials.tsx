import { Github, Instagram, Linkedin, MessageCircle } from "lucide-react";
import { site } from "@/data/site";

export default function Socials({ includeWhatsApp = false }: { includeWhatsApp?: boolean }) {
  const profiles = [
    { name: "GitHub", href: site.socials.github, Icon: Github },
    { name: "LinkedIn", href: site.socials.linkedin, Icon: Linkedin },
    { name: "Instagram", href: site.socials.instagram, Icon: Instagram },
    ...(includeWhatsApp ? [{ name: "WhatsApp", href: site.socials.whatsapp, Icon: MessageCircle }] : []),
  ].filter((profile) => profile.href);

  if (profiles.length === 0) return null;

  return (
    <ul className="social-links" aria-label="Social links">
      {profiles.map(({ name, href, Icon }) => (
        <li key={name}>
          <a href={href} target="_blank" rel="noopener noreferrer" aria-label={name} title={name}>
            <Icon size={17} aria-hidden="true" />
          </a>
        </li>
      ))}
    </ul>
  );
}

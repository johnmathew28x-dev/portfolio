import { ArrowUpRight, BookOpenCheck, Layers3 } from "lucide-react";
import { site } from "@/data/site";

export default function Experience() {
  return (
    <section id="experience" className="section-shell section-divider experience-section">
      <div className="container section-content">
        <div className="section-heading" data-reveal>
          <p className="eyebrow">05 / Education and experience</p>
          <h2>Learning by<br /><span>making and doing.</span></h2>
          <p className="section-lede">My foundation is growing through formal study and practical project work.</p>
        </div>

        <div className="experience-grid">
          <article className="experience-card education-timeline" data-reveal>
            <div className="experience-card-heading"><span className="card-icon card-icon-cyan"><BookOpenCheck size={19} /></span><span className="card-kicker">Education</span></div>
            <div className="timeline-entry">
              <span className="timeline-dot" />
              <p className="education-period">{site.education[0]?.period}</p>
              <h3>{site.education[0]?.school}</h3>
              <p className="card-muted">{site.education[0]?.program}</p>
              <span className="timeline-line" />
            </div>
          </article>

          <article className="experience-card project-learning" data-reveal data-reveal-delay="100">
            <div className="experience-card-heading"><span className="card-icon card-icon-purple"><Layers3 size={19} /></span><span className="card-kicker">Project-based learning</span></div>
            <h3>Turning coursework into practical tools.</h3>
            <p className="card-muted">I apply what I’m learning across web and mobile projects, with attention to clear interfaces, useful workflows, and the details that help a product feel complete.</p>
            <a className="text-link" href="#projects">Explore selected projects <ArrowUpRight size={15} /></a>
            <span className="learning-decoration" aria-hidden="true"><i /><i /><i /></span>
          </article>
        </div>
      </div>
    </section>
  );
}

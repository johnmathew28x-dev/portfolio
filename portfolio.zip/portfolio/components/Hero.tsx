import { ArrowDown, ArrowUpRight, Download, Sparkles } from "lucide-react";
import Image from "next/image";
import { site } from "@/data/site";
import Socials from "./Socials";

export default function Hero() {
  return (
    <section id="top" className="hero-section section-shell">
      <div className="hero-grid" aria-hidden="true" />
      <div className="hero-glow hero-glow-one" aria-hidden="true" />
      <div className="hero-glow hero-glow-two" aria-hidden="true" />

      <div className="container hero-layout">
        <div className="hero-copy" data-reveal>
          <p className="eyebrow"><span className="eyebrow-spark"><Sparkles size={13} /></span> A portfolio by John Matthew Ong</p>
          <p className="hero-greeting">Hello, I&apos;m</p>
          <h1>
            {site.name}
            <span className="hero-title">{site.title}</span>
          </h1>
          <p className="hero-intro">{site.tagline}</p>

          <div className="hero-actions">
            <a className="button button-primary" href="#projects">
              Explore projects <ArrowUpRight size={16} />
            </a>
            <a
              className="button button-secondary"
              href="/john-matthew-ong-resume.pdf"
              download="John-Matthew-Ong-Resume.pdf"
            >
              Download resume <Download size={16} />
            </a>
            <a className="button button-secondary" href="#contact">
              Get in touch
            </a>
          </div>

          <div className="hero-socials">
            <span className="hero-social-label">Find me</span>
            <Socials />
          </div>
        </div>

        <div className="hero-visual" data-reveal data-reveal-delay="140">
          <div className="hero-orbit orbit-one" aria-hidden="true" />
          <div className="hero-orbit orbit-two" aria-hidden="true" />
          <div className="hero-orbit orbit-three" aria-hidden="true" />
          <span className="orbit-star orbit-star-one" aria-hidden="true"><Sparkles size={13} /></span>
          <span className="orbit-star orbit-star-two" aria-hidden="true"><Sparkles size={10} /></span>
          <div className="orbit-satellite-path" aria-hidden="true">
            <span className="orbit-satellite satellite-sparkle"><Sparkles size={11} /></span>
            <span className="orbit-satellite satellite-dot" />
          </div>
          <div className="portrait-wrap">
            <div className="portrait-image">
              <Image
                src="/profile.jpg"
                alt={`Portrait of ${site.name}`}
                width={874}
                height={874}
                priority
                sizes="(max-width: 768px) 78vw, 420px"
              />
            </div>
            <div className="portrait-caption">
              <span className="portrait-caption-mark">JM</span>
              <span>
                <strong>{site.name}</strong>
                <small>Information Technology student</small>
              </span>
              <span className="portrait-caption-dot" aria-hidden="true" />
            </div>
          </div>
          <div className="floating-note note-top"><span className="note-dot" /> Open to learning</div>
          <div className="floating-note note-bottom">Design <span>×</span> Development</div>
        </div>
      </div>

      <a className="scroll-cue" href="#about" aria-label="Scroll to About">
        <span>Scroll to explore</span><ArrowDown size={14} />
      </a>
    </section>
  );
}

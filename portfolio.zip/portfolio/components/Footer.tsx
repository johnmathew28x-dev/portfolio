import { ArrowUp } from "lucide-react";
import { site } from "@/data/site";
import Socials from "./Socials";

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-content">
        <a className="footer-brand" href="#top" aria-label={`${site.name}, back to top`}>
          <span className="brand-monogram">{site.initials}</span>
          <span>{site.name}</span>
        </a>
        <p>© {new Date().getFullYear()} {site.name}. Designed with care.</p>
        <div className="footer-actions">
          <Socials />
          <a className="back-to-top" href="#top"><ArrowUp size={15} /> Back to top</a>
        </div>
      </div>
    </footer>
  );
}

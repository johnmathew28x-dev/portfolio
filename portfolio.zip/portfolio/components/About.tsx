import { ArrowUpRight, GraduationCap, Sparkles } from "lucide-react";
import { site, strengths } from "@/data/site";

export default function About() {
  const currentEducation = site.education[0];

  return (
    <section id="about" className="section-shell section-divider">
      <div className="container section-content">
        <div className="section-heading" data-reveal>
          <p className="eyebrow">01 / About</p>
          <h2>Curious by nature.<br /><span>Thoughtful in every detail.</span></h2>
          <p className="section-lede">A little about what I’m learning, how I work, and where I want to go.</p>
        </div>

        <div className="bento-grid about-grid">
          <article className="bento-card about-main" data-reveal>
            <div className="card-icon"><Sparkles size={18} /></div>
            <p className="card-kicker">A little about me</p>
            <p className="about-copy">{site.about}</p>
            <a className="text-link" href="#experience">My learning journey <ArrowUpRight size={15} /></a>
            <span className="card-orb card-orb-purple" aria-hidden="true" />
          </article>

          {currentEducation && (
            <article className="bento-card about-education" data-reveal data-reveal-delay="80">
              <div className="card-icon card-icon-cyan"><GraduationCap size={19} /></div>
              <p className="card-kicker">Education</p>
              <p className="education-period">{currentEducation.period}</p>
              <h3>{currentEducation.school}</h3>
              <p className="card-muted">{currentEducation.program}</p>
              <span className="education-status"><span /> Currently studying</span>
            </article>
          )}

          <article className="bento-card about-strengths" data-reveal data-reveal-delay="140">
            <p className="card-kicker">How I show up</p>
            <h3>Good work is a team effort.</h3>
            <p className="card-muted">The values I bring into learning and collaboration.</p>
            <ul className="strength-list">
              {strengths.map((strength) => <li key={strength}>{strength}</li>)}
            </ul>
          </article>

          <article className="bento-card about-focus" data-reveal data-reveal-delay="200">
            <div>
              <p className="card-kicker">What I enjoy</p>
              <h3>Building useful things for the web.</h3>
              <p className="card-muted">From the structure and logic to the final visual polish, I like seeing each piece come together.</p>
            </div>
            <div className="focus-tiles" aria-hidden="true">
              <span className="focus-tile focus-tile-one">&lt;/&gt;</span>
              <span className="focus-tile focus-tile-two">✳</span>
              <span className="focus-tile focus-tile-three">{ }</span>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

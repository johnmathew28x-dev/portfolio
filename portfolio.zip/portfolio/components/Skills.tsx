import { Braces, Database, Palette, Smartphone } from "lucide-react";
import { skillGroups } from "@/data/site";

const groupIcons = [Braces, Smartphone, Database, Palette];

export default function Skills() {
  return (
    <section id="skills" className="section-shell section-divider skills-section">
      <div className="container section-content">
        <div className="section-heading section-heading-row" data-reveal>
          <div>
            <p className="eyebrow">02 / Skills</p>
            <h2>Tools I use to<br /><span>make ideas real.</span></h2>
          </div>
          <p className="section-lede">A growing toolkit across web development, data, and visual design.</p>
        </div>

        <div className="skill-grid">
          {skillGroups.map((group, index) => {
            const Icon = groupIcons[index] ?? Braces;
            return (
              <article className="skill-card" key={group.name} data-reveal data-reveal-delay={index * 90}>
                <div className="skill-card-top">
                  <span className={`skill-icon skill-icon-${index}`}><Icon size={19} /></span>
                  <span className="skill-index">0{index + 1}</span>
                </div>
                <h3>{group.name}</h3>
                <p>{group.description}</p>
                <ul className="skill-tags">
                  {group.items.map((skill) => <li key={skill}>{skill}</li>)}
                </ul>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

import { ArrowUpRight, Mail } from "lucide-react";
import { site } from "@/data/site";
import Socials from "./Socials";

const hasSocial = Object.values(site.socials).some(Boolean);

export default function Contact() {
  return (
    <section id="contact" className="section-shell section-divider contact-section">
      <div className="contact-glow" aria-hidden="true" />
      <div className="container contact-content" data-reveal>
          <p className="eyebrow">06 / Contact</p>
        <h2>Have an idea<br /><span>you’d like to build?</span></h2>
        <p className="contact-copy">I’m open to learning, collaboration, and thoughtful conversations about web development and design.</p>
        <div className="contact-actions">
          {site.email && (
            <a className="button button-primary" href={`mailto:${site.email}`}>
              <Mail size={16} /> {site.email} <ArrowUpRight size={15} />
            </a>
          )}
          <Socials includeWhatsApp />
        </div>
        {!site.email && !hasSocial && <p className="contact-note">Contact links can be added in <code>data/site.ts</code>.</p>}
      </div>
    </section>
  );
}

import Image from "next/image";
import { ArrowUpRight, Award } from "lucide-react";
import { certifications } from "@/data/certifications";

export default function Certifications() {
  return (
    <section id="certifications" className="section-shell section-divider certifications-section">
      <div className="container section-content">
        <div className="section-heading section-heading-row" data-reveal>
          <div>
            <p className="eyebrow">04 / Certification</p>
            <h2>Learning that earns<br /><span>a closer look.</span></h2>
          </div>
          <p className="section-lede">Certificates, course completions, and learning milestones.</p>
        </div>

        {certifications.length > 0 ? (
          <div className="certification-grid">
            {certifications.map((certification, index) => (
              <article className="certification-card" key={`${certification.issuer}-${certification.name}`} data-reveal data-reveal-delay={index * 90}>
                <a className="certification-preview" href={certification.credentialUrl ?? certification.preview} target="_blank" rel="noopener noreferrer" aria-label={`Open ${certification.name}`}>
                  <Image src={certification.preview} alt={`${certification.name} certificate`} width={1200} height={850} sizes="(max-width: 720px) 100vw, (max-width: 1100px) 50vw, 33vw" />
                  <span className="certification-preview-hint">View certificate <ArrowUpRight size={14} /></span>
                </a>
                <div className="certification-card-top">
                  <span className="certification-icon"><Award size={20} /></span>
                  <span className="certification-date">{certification.issued}</span>
                </div>
                <h3>{certification.name}</h3>
                <p className="card-muted">{certification.issuer}</p>
                {certification.credentialUrl && (
                  <a className="text-link" href={certification.credentialUrl} target="_blank" rel="noopener noreferrer">
                    {certification.credentialLabel ?? "View certificate"} <ArrowUpRight size={15} />
                  </a>
                )}
              </article>
            ))}
          </div>
        ) : (
          <article className="certification-empty" data-reveal>
            <span className="certification-empty-icon"><Award size={24} /></span>
            <div className="certification-empty-copy">
              <p className="card-kicker">Certificates & learning milestones</p>
              <h3>Certifications will appear here.</h3>
              <p className="card-muted">This space is ready for earned credentials and completed courses.</p>
            </div>
            <div className="certificate-art" aria-hidden="true">
              <span className="certificate-art-seal"><Award size={19} /></span>
              <i /><i /><i />
            </div>
          </article>
        )}
      </div>
    </section>
  );
}

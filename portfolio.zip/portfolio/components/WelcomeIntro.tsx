"use client";

import { ArrowUpRight, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import { site } from "@/data/site";

export default function WelcomeIntro() {
  const [phase, setPhase] = useState<"welcome" | "exit" | "hidden">("welcome");

  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const exitTimer = window.setTimeout(() => setPhase("exit"), reduceMotion ? 80 : 1900);
    const removeTimer = window.setTimeout(() => setPhase("hidden"), reduceMotion ? 180 : 2350);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(removeTimer);
    };
  }, []);

  if (phase === "hidden") return null;

  function skipIntro() {
    setPhase("exit");
    window.setTimeout(() => setPhase("hidden"), 360);
  }

  return (
    <div
      className={`welcome-intro${phase === "exit" ? " is-leaving" : ""}`}
      role="status"
      aria-label={`Welcome to ${site.name}'s portfolio`}
      aria-live="polite"
    >
      <div className="welcome-intro-glow welcome-intro-glow-one" aria-hidden="true" />
      <div className="welcome-intro-glow welcome-intro-glow-two" aria-hidden="true" />

      <div className="welcome-intro-content">
        <span className="welcome-intro-mark"><Sparkles size={22} /></span>
        <p className="welcome-intro-eyebrow">A PORTFOLIO BY</p>
        <h1>{site.name}</h1>
        <p className="welcome-intro-subtitle">Programmer <span>×</span> Web &amp; Visual Design</p>
        <div className="welcome-intro-progress" aria-hidden="true"><span /></div>
        <p className="welcome-intro-loading">Preparing my portfolio<span>...</span></p>
      </div>

      <button className="welcome-intro-skip" type="button" onClick={skipIntro}>
        Skip intro <ArrowUpRight size={14} />
      </button>
    </div>
  );
}
